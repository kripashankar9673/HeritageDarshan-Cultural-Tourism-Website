// Toggle Navigation Menu for Mobile
const menuBtn = document.getElementById("menu-btn");
const navLinks = document.getElementById("nav-links");
const menuBtnIcon = menuBtn.querySelector("i");

menuBtn.addEventListener("click", (e) => {
    navLinks.classList.toggle("open");

    const isOpen = navLinks.classList.contains("open");
    menuBtnIcon.setAttribute("class", isOpen ? "ri-close-line" : "ri-menu-line");
});

// Close Navigation Menu on Link Click
navLinks.addEventListener("click", (e) => {
    navLinks.classList.remove("open");
    menuBtnIcon.setAttribute("class", "ri-menu-line");
});

// ScrollReveal Animations
const scrollRevealOption = {
    origin: "bottom",
    distance: "50px",
    duration: 1000,
};

// Header Section Animations
ScrollReveal().reveal(".header__image img", {
    ...scrollRevealOption,
    origin: "right",
});
ScrollReveal().reveal(".header__content p", {
    ...scrollRevealOption,
    delay: 500,
});
ScrollReveal().reveal(".header__content h1", {
    ...scrollRevealOption,
    delay: 1000,
});
ScrollReveal().reveal(".header__btns", {
    ...scrollRevealOption,
    delay: 1500,
});

// About Section Animations
ScrollReveal().reveal(".about__card", {
    ...scrollRevealOption,
    interval: 500,
});

// Resources Section Animations
ScrollReveal().reveal(".resources__card", {
    ...scrollRevealOption,
    interval: 500,
});

// Popular Places Section Animations
ScrollReveal().reveal(".places__card", {
    ...scrollRevealOption,
    interval: 500,
});

// Guide Information Section Animations
ScrollReveal().reveal(".guide__card", {
    ...scrollRevealOption,
    interval: 500,
});

// Swiper for Testimonials Section
const swiper = new Swiper(".swiper", {
    slidesPerView: 1,
    spaceBetween: 20,
    loop: true,
    autoplay: {
        delay: 3000,
        disableOnInteraction: false,
    },
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    breakpoints: {
        768: {
            slidesPerView: 2,
        },
        1024: {
            slidesPerView: 3,
        },
    },
});