// Data for all states with forts, sanctuaries, and temples
const stateData = {
    Maharashtra: {
        title: "Maharashtra",
        description: "Explore the rich cultural heritage of Maharashtra, including ancient forts, wildlife sanctuaries, and historic temples.",
        forts: [
            { name: "Raigad Fort", image: "images/maharashtra/raigad_fort.jpg", info: "Historic fort associated with Chhatrapati Shivaji Maharaj." },
            { name: "Sinhagad Fort", image: "images/maharashtra/sinhagad.jpg", info: "A fort with historic importance and scenic beauty." },
            { name: "Pratapgad Fort", image: "images/maharashtra/pratapgad.jpg", info: "Famous for the battle between Shivaji Maharaj and Afzal Khan." },
            { name: "Rajgad Fort", image: "images/maharashtra/rajgad.jpg", info: "Once the capital of the Maratha Empire." },
            { name: "Torna Fort", image: "images/maharashtra/torna.jpg", info: "First fort captured by Shivaji Maharaj." },
            { name: "Lohagad Fort", image: "images/maharashtra/lohagad.jpg", info: "A UNESCO World Heritage site known for its architecture." }
        ],
        temples: [
            { name: "Shirdi Temple", image: "images/maharashtra/shirdi.jpg", info: "Sacred pilgrimage site dedicated to Sai Baba." },
            { name: "Bhimashankar Temple", image: "images/maharashtra/bhimashankar.jpg", info: "One of the 12 Jyotirlingas in India." },
            { name: "Trimbakeshwar Temple", image: "images/maharashtra/trimbakeshwar.jpg", info: "Famous Jyotirlinga temple near Nashik." },
            { name: "Mahabaleshwar Temple", image: "images/maharashtra/mahabaleshwar.jpg", info: "Ancient temple dedicated to Lord Shiva." },
            { name: "Grishneshwar Temple", image: "images/maharashtra/grishneshwar.jpg", info: "Last Jyotirlinga temple located near Ellora caves." },
            { name: "Jejuri Temple", image: "images/maharashtra/jejuri.jpg", info: "Popular for the worship of Lord Khandoba." }
        ],
        sanctuaries: [
            { name: "Tadoba National Park", image: "images/maharashtra/tadoba.jpg", info: "A famous tiger reserve known for rich biodiversity." },
            { name: "Koyna Wildlife Sanctuary", image: "images/maharashtra/koyna.jpg", info: "UNESCO World Heritage site with lush greenery." },
            { name: "Melghat Tiger Reserve", image: "images/maharashtra/melghat.jpg", info: "Home to the Bengal tiger and other wildlife." }
        ]
    },
    Rajasthan: {
        title: "Rajasthan",
        description: "Discover the grandeur of Rajasthan through its majestic forts, serene sanctuaries, and sacred temples.",
        forts: [
            { name: "Amber Fort", image: "images/rajasthan/amber_fort.jpg", info: "A stunning blend of Hindu and Mughal architecture." },
            { name: "Mehrangarh Fort", image: "images/rajasthan/mehrangarh.jpg", info: "A massive fort overlooking Jodhpur city." },
            { name: "Chittorgarh Fort", image: "images/rajasthan/chittorgarh.jpg", info: "A UNESCO World Heritage fort known for its history." },
            { name: "Jaisalmer Fort", image: "images/rajasthan/jaisalmer.jpg", info: "A living fort with ancient architecture." },
            { name: "Kumbhalgarh Fort", image: "images/rajasthan/kumbhalgarh.jpg", info: "Famous for its massive walls and scenic views." },
            { name: "Nahargarh Fort", image: "images/rajasthan/nahargarh.jpg", info: "A hilltop fort offering stunning views of Jaipur." }
        ],
        temples: [
            { name: "Dilwara Temples", image: "images/rajasthan/dilwara.jpg", info: "Exquisite Jain temples known for marble carvings." },
            { name: "Karni Mata Temple", image: "images/rajasthan/karni_mata.jpg", info: "Known as the 'Rat Temple' with thousands of rats." },
            { name: "Govind Dev Ji Temple", image: "images/rajasthan/govind_dev.jpg", info: "Famous for Lord Krishna's idol." },
            { name: "Eklingji Temple", image: "images/rajasthan/eklingji.jpg", info: "Dedicated to Lord Shiva with intricate architecture." },
            { name: "Brahma Temple", image: "images/rajasthan/brahma.jpg", info: "One of the few temples dedicated to Lord Brahma." },
            { name: "Ranakpur Jain Temple", image: "images/rajasthan/ranakpur.jpg", info: "Renowned for its stunning marble architecture." }
        ],
        sanctuaries: [
            { name: "Ranthambore National Park", image: "images/rajasthan/ranthambore.jpg", info: "Renowned for its Bengal tiger population." },
            { name: "Keoladeo National Park", image: "images/rajasthan/keoladeo.jpg", info: "A UNESCO site famous for birdwatching." }
        ]
    }
};

// Function to get query parameters from URL
function getQueryParam(param) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
}

// Load data based on state selection
function loadStateData() {
    const state = getQueryParam("state");

    if (state && stateData[state]) {
        const { title, description, forts, temples, sanctuaries } = stateData[state];

        document.getElementById("title").textContent = title;
        document.getElementById("description").textContent = description;

        const sections = { forts, temples, sanctuaries };

        for (const [section, items] of Object.entries(sections)) {
            const container = document.getElementById(section);
            container.innerHTML = "";

            items.forEach(item => {
                const card = document.createElement("div");
                card.className = "card";
                card.innerHTML = `
                    <img src="${item.image}" alt="${item.name}">
                    <h3>${item.name}</h3>
                    <p>${item.info}</p>
                `;
                container.appendChild(card);
            });
        }
    }
}

// Load content when the page is ready
window.onload = loadStateData;